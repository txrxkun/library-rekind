####Sejarah Peminjaman
Berisi data transaksi koleksi yang pernah dipinjam.
Data yang muncul terdiri dari:
- Member ID,
- Member Name,
- Item Code,
- Title,
- Loan date,
- Due date.

Dalam menu ini disediakan pula fasilitas untuk mencetak daftar history peminjaman.
Selain itu dimungkinkan pula untuk melakukan pencarian data history.

Pencarian data history ini dilakukan berdasarkan:
- Member ID/Member Name,
- Document Title,
- Item Code,
- Loan Date From
- Loan Date Until.

Fasilitas ini dapat di tampilkan dengan mengklik Show More Filter Options. 
