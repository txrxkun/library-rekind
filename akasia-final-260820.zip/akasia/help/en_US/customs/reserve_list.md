####Reservation Menu

This menu is used to view a list of reservations by the members. Item information contained in this menu is: 
- Item Code, 
- Title, 
- Member, 
- Reserve Date.

Note:
Reserve collection is collection that is not in hand/library at that moment and not a self-lent collection.
