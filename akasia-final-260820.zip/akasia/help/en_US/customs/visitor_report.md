###Visitor Statistic

This is a report that contains statistics of library visitors. This report contains:
- Member Type, and 
- Number of visits in each month in the year specified. 

Determination based on this year's report can be done through the filter.
