#### Master File / Collection Type
<hr>
The type of item collections owned by the library, for example: Textbook, Reference
