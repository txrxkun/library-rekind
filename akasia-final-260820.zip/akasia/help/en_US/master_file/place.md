####Master File / Publishing Place
<hr>
Contains the place of publication
Example: Jakarta, London
