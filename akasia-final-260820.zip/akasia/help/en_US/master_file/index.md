#### Master File / GMD
<hr>
In this module we can enter the master file data that can be used as a master in bibliographic data entry. 
- GMD General Material Designation – The physical form of the media item 