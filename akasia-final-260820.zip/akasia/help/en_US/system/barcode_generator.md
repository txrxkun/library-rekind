###Barcode Generator

Enter the code that will be made into a barcode in the columns on the screen. Determine the size of the barcode (Small, Medium, or Big), and click the Generate Barcode. Then it will be seen in the form of a barcode , inHtml and can be printed in a printer. The default encoding used is barcode 128B. You can modify this barcode encoding in the Senayan global configuration file , sysconfig.inc.php.

Note:
The characters that can be processed in the Barcode Generator are just the alphanumeric character set.
