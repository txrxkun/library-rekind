### Current Lost Items
<hr>
The contents of this menu is a list of items that are considered missing at the time of stock-taking, in addition to items on loan.
