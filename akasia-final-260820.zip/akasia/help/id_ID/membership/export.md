#### Eksport data anggota
 <hr>
Anda dapat melakukan proses eksport dengen fitur ini. Hasil eksport akan berbentuk file .csv (comma separated value). File ini dapat diedit dengan spreadsheet atau text editor. Hasil eksport dapat diimport ke aplikasi SLiMS yang lain, atau digunakan untuk kepentingan lainnya
