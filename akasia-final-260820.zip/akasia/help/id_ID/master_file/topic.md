####Master File / Subyek
<hr>
Gunakan fitur ini untuk mengisi
- daftar tajuk subyek,
- kode klasifikasi,
- tipe subjek, dan
- authority files.
