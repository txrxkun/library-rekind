### Statistik pengunjung
<hr>
Merupakan laporan yang berisi statistik pengunjung perpustakaan. Data yang masuk adalah data anggota yang melakukan pendataan pada saat masuk perpustakaan melalui fasilitas absensi. Laporan ini berisi Member Type, dan jumlah kunjungan pada tiap bulan pada tahun yang ditentukan. Penentuan laporan berdasar tahun ini dapat dilakukan melalui Filter.