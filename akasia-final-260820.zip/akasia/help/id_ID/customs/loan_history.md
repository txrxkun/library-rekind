####Sejarah Peminjaman

Berisi laporan/daftar sejarah peminjaman perpustakaan. Dalam menu ini terdapat fasilitas untuk mengurutkan dan mencetak. Pada menu ini, dapat pula dilakukan penapisan dengan menuliskan Member ID/Member Name, atau dengan menampilkan fasilitas tapis lainnya. Caranya dengan klik "Show More Filter Options." 
