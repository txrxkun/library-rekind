####Daftar Keterlambatan
<hr>
Merupakan fasilitas untuk mengetahui anggota-anggota dengan status terlambat.
Informasi yang ditampilkan dalam fasilitas ini adalah
- No Anggota,
- Nama Anggota,
- Title,
- Lama keterlambatan,
- Tanggal Pinjam,
- Due Date

Dengan Menu ini pula kita dapat melakukan pencetakan dan pencarian data keterlambatan. Pencarian data keterlambatan dilakukan berdasarkan kategori Member ID/Member Name, Loan Date From, Loan Date Until.
