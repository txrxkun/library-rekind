### Pengaturan sistem
<hr> 
Form dalam modul ini dapat anda gunakan untuk melakukan pengubahan preferensi global aplikasi Senayan, yang terdiri dari:
 - Library Name,
 - Public Template (tampilan OPAC),
 - Default Application Language,
 - Admin Template (tampilan Admin),
 - Number of Collections to Show in OPAC Result List (jumlah koleksi yang akan ditampilkan pada setiap halaman di OPAC),
 - Show Promoted Titles at Homepage (menampilkan Judul dalam halaman awal),
 - Disable/Enable Quick Return (untuk memperbolehkan pengembalian koleksi dengan metode cepat),
 - Loan Limit Overrride (Pengabaian Batas Pinjam),
 - Disable/Enable detail XML di OPAC,
 - Disable/Enable hasil XML di OPAC, seting Allow (mengijinkan) atau Forbid (melarang) pengunjung/pengguna untuk mengunduh file attachment di OPAC,
 - Enable Search Spellchecker untuk seting pengecekan katakunci (fitur ini menggunakan Enchant library. silakan baca tips dan trik),
 - Session Login Timeout,
 - Barcode Encoding. Dalam menu ini pula, kita dapat melihat versi senayan yang kita gunakan.

Fitur Show Promoted Titles at Homepage pada Modul System ini, jika di chek box, maka tampilan depan OPAC akan kosong, kecuali jika ada data bibliografi yang diset untuk di tampilkan pada halaman depan. Lihat menu add new bibliografi pada modul bibliografi.

Mulai Senayan3-stable11, terdapat fitur untuk menentukan tanggal pinjam dan kembali secara manual. Fitur ini dapat diaktifkan melalui Modul System Configuration, bagian Loan and Due Date Manual Change. (Penggunaan fitur ini lihat pada bagian Modul Circulation).

Default application language akan berpengaruh pada default bahasa yang digunakan oleh SLiMS.
