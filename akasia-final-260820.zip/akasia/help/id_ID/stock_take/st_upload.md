### Unggah daftar
<hr>
Menu ini digunakan untuk melakukan stock take otomatis dengan memanfaatkan file data item. Untuk dapat menggunakan Upload List, pertama data item senayan harus dieksport, kemudian khusus item disimpan dalam file .txt secara berbaris.
