### Laporan inventarisasi
<hr>
Menu ini untuk melihat hasil dari kegiatan stocke take yang telah dilakukan. Bentuknya berupa laporan (report) yang memuat informasi tentang jumlah koleksi yang hilang, yang sedang dipinjam dan sebaginya. Menu ini tidak berfungsi apabila proses Initialize belum dilakukan.
