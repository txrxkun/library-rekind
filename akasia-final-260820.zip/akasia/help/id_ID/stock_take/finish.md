### Selesaikan inventarisasi
<hr>
Klik tombol "selesaikan inventarisasi" apabila anda telah selesai melakukan stock opname. Dalam fitur ini terdapat sub menu Purge Lost Item. Apabila anda memberikan tanda cek pada Yes, maka data item pada bibliography yang berada dalam Current Lost Item akan ditandai dengan “Missing”.
