####Cetak Barcode Eksemplar 
<hr>
Menu ini sebagai sarana mencetak barcode berdasar data item yang sudah dimasukkan dalam SLiMS. Berikut urutan mencetak barcode menggunakan menu Item Barcodes Printing:
- Klik Item Barcode Printing, maka akan muncul tampilan sebagai berikut:
- Pilih item yang akan dicetak. Gunakan tombol Shift+klik kotak check box untuk memilih lebih dari satu secara berurutan dengan cepat. Catatan: sekali cetak maksimal 50 data.
- Klik Add to Print Queue untuk memasukkan ke antrian cetak.
- Klik Print Selected Data untuk mulai mencetak. maka akan muncul pop-up yang meminta kita untuk mencetak.
