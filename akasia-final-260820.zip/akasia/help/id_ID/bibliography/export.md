####Export Data
<hr>
Menu export data ini digunakan untuk mengambil data bibliografi dalam aplikasi Senayan, untuk kemudian dapat di masukkan dalam aplikasi senayan lainnya. Proses ini dapat dipahami sebagai pertukaran data.
Proses eksport akan menghasilkan file .csv, sedangkan proses import membutuhkan file dengan format .cvs.
Format .csv tersebut adalah berurutan sebagai berikut:
- Judul,
- GMD,
- Edisi,
- ISBN,
- Penerbit,
- Tahun Terbit,
- Deskripsi Fisik,
- Judul Seri,
- Nomor Panggil,
- Bahasa,
- Tempat Terbit,
- Klasifikasi,
- Catatan,
- Nama file Image,
- Nama file attachment,
- Pengarang,
- Subyek,
- Barcode.
