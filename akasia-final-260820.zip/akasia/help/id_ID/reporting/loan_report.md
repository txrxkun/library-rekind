### Laporan Peminjaman
<hr>
Berisi informasi seputar peminjaman. Terdiri dari: total peminjaman, peminjaman berdasar GMD, peminjaman berdasar tipe koleksi, total transaksi peminjaman, rata-rata transaksi per hari, anggota yang sedang mempunyai pinjaman, anggota yang tidak mempunyai pinjaman, dan total peminjaman yang terlambat. 